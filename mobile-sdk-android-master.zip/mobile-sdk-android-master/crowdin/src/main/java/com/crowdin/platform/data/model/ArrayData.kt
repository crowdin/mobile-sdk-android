package com.crowdin.platform.data.model

internal class ArrayData(
    var name: String = "",
    var values: Array<String>? = null
)
