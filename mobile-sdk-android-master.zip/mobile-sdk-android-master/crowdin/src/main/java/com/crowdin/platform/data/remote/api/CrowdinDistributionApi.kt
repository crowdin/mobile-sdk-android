package com.crowdin.platform.data.remote.api

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Query

internal interface CrowdinDistributionApi {

    @GET("/{distributionHash}/content{filePath}")
    fun getResourceFile(
        @Header("if-none-match") eTag: String,
        @Path("distributionHash") distributionHash: String,
        @Path("filePath") filePath: String,
        @Query("timestamp") timeStamp: Long
    ): Call<ResponseBody>

    @GET("/{distributionHash}/manifest.json")
    fun getResourceManifest(
        @Path("distributionHash") distributionHash: String
    ): Call<ResponseBody>

    @GET("/{distributionHash}/mapping{filePath}")
    fun getMappingFile(
        @Header("if-none-match") eTag: String,
        @Path("distributionHash") distributionHash: String,
        @Path("filePath") filePath: String
    ): Call<ResponseBody>
}
