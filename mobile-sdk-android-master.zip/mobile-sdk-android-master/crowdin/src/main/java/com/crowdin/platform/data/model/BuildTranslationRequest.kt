package com.crowdin.platform.data.model

data class BuildTranslationRequest(val targetLanguageId: String)
