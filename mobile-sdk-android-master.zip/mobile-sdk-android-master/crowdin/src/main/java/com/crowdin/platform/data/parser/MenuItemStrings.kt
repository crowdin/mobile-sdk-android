package com.crowdin.platform.data.parser

internal data class MenuItemStrings(
    var title: Int = 0,
    var titleCondensed: Int = 0
)
